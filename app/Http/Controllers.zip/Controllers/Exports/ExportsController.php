<?php

namespace App\Http\Controllers\Exports;

use App\Events\exports_added;
use App\Exporter_transaction;
use App\Exports\ExportsExport;
use App\Exports_item;
use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\Export;
use App\Item;
use App\Name;
use App\Payment;
use App\Store;
use App\User;
use Carbon\Carbon;
use Cassandra\Date;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Event;
use Maatwebsite\Excel\Facades\Excel;
use SebastianBergmann\Exporter\Exporter;

class ExportsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {

        $exports = Export::orderBy('created_at', 'desc')->get();
        $tempMonthYear =0;
        $tempDay = 0;

        //This temp export is added in order to loop through all the orders.
        $temp_export=new Export();
        $temp_export->created_at=Carbon::create(2018);
        $exports->push($temp_export);
        $size = count($exports);
          $has_id=0;
        return view('exports.index', compact('exports',"size","tempDay","tempMonthYear","has_id"));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {    $names=Name::all();
         $exporters=\App\exporter::all();
        return view('exports.create',compact("names","exporters"));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function store(Request $request)
    {

        $requestData = $request->all();


        // first store export
        $export=new Export();
        $export->total_price_after_discount=$request->total_price_after_discount;
        $export->discount=$request->discount;
        $export->no_of_items=sizeof($request->items_id);
        $export_date=Carbon::parse($request->receiving_dates);
       /* $export_date->hour=Carbon::now()->hour;
        $export_date->minute=Carbon::now()->minute;
        */
        $export->receiving_dates=$export_date;
        $export->receipt_id=$request->receipt_id;
        $export->exporter_id=$request->exporter_id;
        $export->user_id=Auth::user()->id;

        $export->save();
        //then store each item
        $ids_array=$request->items_id;
        $quantity_array=$request->items_quantity;
        $size_array=$request->items_size;
        $buying_price_array=$request->items_buying_price;
        $selling_price_array=$request->items_selling_price;
        $discount_array=$request->items_discount;
        $array_size=sizeof($ids_array);
        for($i=0;$i<$array_size;$i++){
            //find this name and check if item with this name added before
            $name=Name::find($ids_array[$i]);
            $item= new Item();
            $item->name_id=$ids_array[$i];
            $item->quantity=$quantity_array[$i];
            $item->size=$size_array[$i];
            $item->buying_price=$buying_price_array[$i];
            $item->selling_price=$selling_price_array[$i];
            $item->discount=$discount_array[$i];
            $item->store_id=DB::table("stores")->first()->id;


            //check if items not exist so add it

            if($item->the_same_item_exist()==null){
                $item->save();

            }
            else{
                $name->items()->where("size",$item->size)->update(["quantity"=>$item->quantity+$item->get_exist_quantity()]);

            }


            //add this item to export_items llfwateeer

            $item->export_id=$export->id;
            Exports_item::create($item->toArray());
            


        }

            $export_transaction=new Exporter_transaction();
            $export_transaction->paid=$request->paid;
            $export_transaction->paid_at=$request->receiving_dates;

            $export_transaction->user_id=Auth::user()->id;
            $export->exporter_transactions()->save($export_transaction);

            $payment=new Payment();
            $payment->method="تم تسديدها في الفاتورة";
            $payment->receipt_id=$request->receipt_id;
            $payment->paid_at=$request->receiving_dates;
            $payment->paid=$request->paid;

            $payment->details=$request->details;
            $payment->exporter_id=$request->exporter_id;
            $payment->save();
        event(new exports_added($export));

       $has_id=0;



        return redirect('exports');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function show($id)
    {
        $export = Export::findOrFail($id);

        return view('exports.show', compact('export'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function edit($id)
    {
        $export = Export::findOrFail($id);

        return view('exports.edit', compact('export'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function update(Request $request, $id)
    {

        $requestData = $request->all();

        $export = Export::findOrFail($id);
        $export->update($requestData);

        return redirect('exports')->with('flash_message', 'Export updated!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function destroy($id)
    {
        $export=Export::find($id);
        foreach ($export->exports_items as $item){
            $export->delete_this_item($item);
        }
        Export::destroy($id);

        return redirect('exports')->with('flash_message', 'Export deleted!');
    }
    public function delete_item(Request $request,$id){
        $export=Export::find($request->id);
        $item=Exports_item::find($id);
        $export->delete_this_item($item);
        return redirect()->back();


    }
    public function transactions($id){
        $export=Export::find($id);
        return view("exporter_transactions.index",compact($export));

    }
    public function export_to_excel(Request $request){

        $exportable=new ExportsExport($request->start,$request->end);


        return Excel::download($exportable, 'exports.xlsx');

    }
    public function exports_with_states(Request $request){
        dd($request);


        $exports=Export::where("state",$request->state)->get();
        $state=$request->state;
        return view("exports_with_states",compact("exports","state"));





    }



}
