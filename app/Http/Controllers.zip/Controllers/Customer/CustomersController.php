<?php

namespace App\Http\Controllers\Customer;

use App\Adress;
use App\Export;
use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\Customer;
use App\Order;
use App\Phone;
use App\Ship;
use App\User;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use PhpParser\Node\Expr\New_;
use Psy\Util\Json;

class CustomersController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {

            $customers = Customer::limit(1)->get();
            $escaped_customers=Customer::where("type","متهرب")->count();
            $normal_customers=Customer::where("type","عادي")->count();
            

        if(Customer::all()->count()>=Auth::user()->no_of_customers){
            return view('customers.index', compact('customers','escaped_customers','normal_customers'))->withErrors(["error"=>"لقد تم تجاوز الحد المسموح من العملاء"]);

        }
        return view('customers.index', compact('customers','escaped_customers','normal_customers'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        return view('customers.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function arraytostr($arr){
        $str="";
        foreach ($arr as $ar){
            $str.=$ar."-";
        }
        return $str;

    }
    public function store(Request $request)
    {

        if(Customer::all()->count()>=Auth::user()->no_of_customers){
            return redirect()->route("customers.index");

        }
        $customer=new Customer();
        $customer->name=$request->name;
        $customer->customer_platform=$request->customer_platform;
        $customer->customer_link=$request->customer_link;
        $customer->governorate=$request->governorate;
        $customer->type="عادي";

       $customer->save();
       foreach ($request->phone as $p) {
           $phone=new Phone();
           $phone->phone=$p;

           $customer->phones()->save($phone);
       }
        foreach ($request->address as $a) {
            $address=new Adress();
            $address->address=$a;
            $customer->addresses()->save($address);
        }
        return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function show($id)
    {

        $dates=Order::where("customer_id",$id)->pluck("created_at");
        $arr=[];
        foreach ($dates as $date){
            $arr[]=explode(" ",$date)[0];

        }
        $arr=array_unique($arr);


        $arr2=[];
        foreach ($arr as $ar){

            $arr2[]=substr($ar,0,7);

        }
        $arr2=array_unique($arr2);

        $final=new Collection([]);

        $final2=[];
        $months=[];
        $items_count=[];

        foreach ($arr2 as $month) {
            $final2 = [];
            foreach ($arr as $day) {
                $temp_count = 0;
                if (substr($day, 0, 7) == $month) {
                    $final2[$day] = Order::where("customer_id",$id)->whereDate('created_at', "=", $day)->get(["total_price_after_discount", "id"]);
                    foreach ($final2[$day] as $order) {

                        $temp_count += $order->items()->sum("quantity");
                    }
                    $items_count[$day] = $temp_count;

                }
            }
            $months[$month] = $final2;
        }


        $has_id=1;
        $ships=Ship::where("type","company")->get();
        $delivery_man=Ship::where("type","person")->get();
        $customer_id=$id;
        $customer=Customer::find($customer_id);
        $users=User::all();
        return view('orders.orders_for_customer',compact("months","final2","arr2","final","has_id","ships","items_count","customer_id","customer","users","delivery_man"));
    }
    public function get_order_for_customer(Request $request,$id){

        $orders=Order::where("customer_id",$id)->whereDate("created_at","=",$request->date)->get();
        foreach ($orders as $order){
            $order->no_of_items=$order->no_of_items();
            $order->customer_name=$order->customer->name;
            $order->username=$order->user->name;
            $order->hour=$order->hour();

            $order->link=route("print",$order->id);
            $order->destroy_link=route("orders.destroy",$order->id);
            $order->edit_link=route("order_edit_create",$order->id);


        }
        return $orders ;
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function edit($id)
    {
        $customer = Customer::findOrFail($id);

        return view('customers.edit', compact('customer'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function update(Request $request, $id)
    {



        $customer = Customer::findOrFail($id);
        if($request->has("phone" )){

            Phone::where("customer_id",$id)->delete();

            foreach ($request->phone as $phone){
                if($phone==null){continue;}
                $new_phone=new Phone();
                $new_phone->phone=$phone;
                $customer->phones()->save($new_phone);
            }



        }
        if($request->has("address" )){
             Adress::where("customer_id",$id)->delete();
            foreach ($request->address as $address){
                if($address==null){continue;}

                $new_address=new Adress();
                $new_address->address=$address;
                $customer->addresses()->save($new_address);
            }

        }
        $request->request->remove("phone");
        $request->request->remove("address");


        $customer->update($request->all());




        return redirect('customers')->with('flash_message', 'Customer updated!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function destroy($id)
    {
        Customer::destroy($id);

        return redirect()->back();
    }
    public function load_more($index){

          $to=$index+5;

         $customers=Customer::where("id",">",$index)->where("id","<=",$to)->get();
         foreach ($customers as $customer){
             $customer->phones= $customer->phones()->pluck("phone");
             $customer->addresses= $customer->addresses()->pluck("address");
         }
         return $customers;


    }
    public function search(Request $request){

        if($request->type=="phone"){
            $phone=Phone::where("phone",$request->value)->first();
            if($phone!=null){
                $customers=Customer::where("id",$phone->customer_id)->get();
                foreach ($customers as $customer){
                    $customer->phones= $customer->phones()->pluck("phone");
                    $customer->addresses= $customer->addresses()->pluck("address");
                }
                return $customers;
            }
        }
        if($request->type=="name"){
            $customers= Customer::where("name",$request->value)->get();

            foreach ($customers as $customer){
                $customer->phones= $customer->phones()->pluck("phone");
                $customer->addresses= $customer->addresses()->pluck("address");
            }
            return $customers;

        }


    }
}
