<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Name;
use App\Permission;
use App\Role;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class UsersController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return void
     */
    public function index(Request $request)
    {
        $keyword = $request->get('search');
        $perPage = 15;

        if (!empty($keyword)) {
            $users = User::where('name', 'LIKE', "%$keyword%")->orWhere('email', 'LIKE', "%$keyword%")
                ->latest()->paginate($perPage);
        } else {
            $users = User::latest()->paginate($perPage);
        }

        return view('admin.users.index', compact('users'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return void
     */
    public function create()
    {
        $roles = Role::select('id', 'name', 'label')->get();
        $roles = $roles->pluck('label', 'name');

        return view('admin.users.create', compact('roles'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     *
     * @return void
     */
    public function store(Request $request)
    {

        $this->validate(
            $request,
            [
                'name' => 'required',
                'password' => 'required',
            ]
        );

        $data = $request->except('password');

        config(['database.connections.mysql.database' => "queen_dashboard"]);
        DB::purge('mysql');

        $data['password'] = bcrypt($request->password);
        $data["account_name"]=Auth::user()->account_name;
        $data["account_type"]=Auth::user()->account_type;
        $data["no_of_users"]=Auth::user()->no_of_users;
        $data["no_of_customers"]=Auth::user()->no_of_customers;
        $data["no_of_orders"]=Auth::user()->no_of_orders;
        $data["currency"]=Auth::user()->currency;
        $data["country"]=Auth::user()->country;

        $user = User::create($data);

        $arr["name"]= $user->name.$data["account_name"];
        $arr["label"]=$user->name.$data["account_name"];

        $data["id"]=$user->id;





        $role = Role::firstOrCreate($arr);
        foreach ($request->permissions as $permission){
            $p=Permission::find($permission);
            $role->givePermissionTo($p);
        }
        $user->assignRole($role->name);
        config(['database.connections.mysql.database' => Auth::user()->account_name]);
        DB::purge('mysql');

        $arr["name"]= $user->name;
        $arr["label"]=$user->name;
        $arr["name"]= $user->name.$data["account_name"];
        $arr["label"]=$user->name.$data["account_name"];
        $data["account_name"]=Auth::user()->account_name;
        $data["account_type"]=Auth::user()->account_type;
        $data["no_of_users"]=Auth::user()->no_of_users;
        $data["no_of_customers"]=Auth::user()->no_of_customers;
        $data["no_of_orders"]=Auth::user()->no_of_orders;
        $data["currency"]=Auth::user()->currency;
        $data["country"]=Auth::user()->country;
        $user = User::create($data);




        $role = Role::firstOrCreate($arr);
        foreach ($request->permissions as $permission){
            $p=Permission::find($permission);
            $role->givePermissionTo($p);
        }
        $user->assignRole($role->name);
        //  DB::setDefaultConnection('tenant');

        $tag="users_tag_button";

        return redirect()->route("setting",["tag"=>$tag]);
    }
    public function get_permission($id){
        $role=Role::find(DB::table("role_user")->where("user_id",$id)->first()->role_id);

        return $role->permissions;



    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     *
     * @return void
     */
    public function show($id)
    {
        $user = User::findOrFail($id);

        return view('admin.users.show', compact('user'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     *
     * @return void
     */
    public function edit($id)
    {
        $roles = Role::select('id', 'name', 'label')->get();
        $roles = $roles->pluck('label', 'name');

        $user = User::with('roles')->select('id', 'name', 'email')->findOrFail($id);
        $user_roles = [];
        foreach ($user->roles as $role) {
            $user_roles[] = $role->name;
        }

        return view('admin.users.edit', compact('user', 'roles', 'user_roles'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int      $id
     *
     * @return void
     */
    public function update(Request $request, $id)
    {
        $this->validate(
            $request,
            [
                'name' => 'required',
                //'email' => 'required|string|max:255|email|unique:users,email,' . $id,
                'password' => 'required'
            ]
        );

        $data = $request->except('password');
        if ($request->has('password')) {
            $data['password'] = bcrypt($request->password);
        }

        $user = User::findOrFail($id);
        $user->update($data);

       /* $user->roles()->detach();
        foreach ($request->roles as $role) {
            $user->assignRole($role);
        }*/

        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     *
     * @return void
     */
    public function destroy($id)
    {
        User::destroy($id);

        return redirect('admin/users')->with('flash_message', 'User deleted!');
    }
}
