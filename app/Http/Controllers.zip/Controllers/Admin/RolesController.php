<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Role;
use App\Permission;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class RolesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return void
     */
    public function index(Request $request)
    {
        $keyword = $request->get('search');
        $perPage = 15;

        if (!empty($keyword)) {
            $roles = Role::where('name', 'LIKE', "%$keyword%")->orWhere('label', 'LIKE', "%$keyword%")
                ->latest()->paginate($perPage);
        } else {
            $roles = Role::latest()->paginate($perPage);
        }

        return view('admin.roles.index', compact('roles'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return void
     */
    public function create()
    {
        $permissions = Permission::select('id', 'name', 'label')->get()->pluck('label', 'name');

        return view('admin.roles.create', compact('permissions'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     *
     * @return void
     */
    public function store(Request $request,$id)
    {


        $this->validate(
            $request,
            [
                'name' => 'required',

            ]
        );
        $user=User::find($id);
        $user->name=$request->name;
        if($request->exists("password")) {
            $user->password = bcrypt($request->password);

        }

        $arr["name"]= $user->name;
        $arr["label"]=$user->name;

        $role = Role::firstOrCreate($arr);
       // dd($role->permissions);
         // dd($request->all());
        $role->permissions()->detach();

        if ($request->has('permissions')) {

            foreach ($request->permissions as $permission_name) {
                $permission = Permission::find($permission_name);
                $role->givePermissionTo($permission);
            }
        }
       // dd($role->permissions);

        if(!DB::table("role_user")->where("user_id",$user->id)->exists()) {
            $user->assignRole($role->name);
        }

        $user->save();
        config(['database.connections.mysql.database' =>env("DB_DATABASE")]);
        DB::purge('mysql');
        $user=User::find($id);
        $user->name=$request->name;
        if($request->exists("password")) {
            $user->password = bcrypt($request->password);

        }
        $arr["name"]= $user->name;
        $arr["label"]=$user->name;

        $role = Role::firstOrCreate($arr);
        // dd($role->permissions);
        // dd($request->all());
        $role->permissions()->detach();

        if ($request->has('permissions')) {

            foreach ($request->permissions as $permission_name) {
                $permission = Permission::find($permission_name);
                $role->givePermissionTo($permission);
            }
        }
        // dd($role->permissions);

        if(!DB::table("role_user")->where("user_id",$user->id)->exists()) {
            $user->assignRole($role->name);
        }

        $user->save();

        //   dd($user->roles()->first()->permissions);
        return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     *
     * @return void
     */
    public function show($id)
    {
        $role = Role::findOrFail($id);

        return view('admin.roles.show', compact('role'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     *
     * @return void
     */
    public function edit($id)
    {
        $role = Role::findOrFail($id);
        $permissions = Permission::select('id', 'name', 'label')->get()->pluck('label', 'name');

        return view('admin.roles.edit', compact('role', 'permissions'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     *
     * @return void
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, ['name' => 'required']);

        $role = Role::findOrFail($id);
        $role->update($request->all());
        $role->permissions()->detach();

        if ($request->has('permissions')) {
            foreach ($request->permissions as $permission_name) {
                $permission = Permission::whereName($permission_name)->first();
                $role->givePermissionTo($permission);
            }
        }

        return redirect('admin/roles')->with('flash_message', 'Role updated!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     *
     * @return void
     */
    public function destroy($id)
    {
        Role::destroy($id);

        return redirect('admin/roles')->with('flash_message', 'Role deleted!');
    }
}
