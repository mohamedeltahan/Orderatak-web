<?php

namespace App\Http\Controllers\ShipDistrict;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\ShipDistrict;
use Illuminate\Http\Request;

class ShipDistrictsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        $keyword = $request->get('search');
        $perPage = 25;

        if (!empty($keyword)) {
            $shipdistricts = ShipDistrict::where('ship_id', 'LIKE', "%$keyword%")
                ->orWhere('district_id', 'LIKE', "%$keyword%")
                ->orWhere('cost', 'LIKE', "%$keyword%")
                ->latest()->paginate($perPage);
        } else {
            $shipdistricts = ShipDistrict::latest()->paginate($perPage);
        }

        return view('ship-districts.index', compact('shipdistricts'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        return view('ship-districts.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function store(Request $request)
    {  
       
        $districts_array=$request->districts;
        $cost_array=$request->cost;
         
        for($i=0; $i<sizeof($cost_array); $i++)
        {
            $requestData["ship_id"]=$request->ship_id;
            $requestData["district_id"]=$districts_array[$i];
            $requestData["cost"]=$cost_array[$i];

            ShipDistrict::create($requestData);


        }
        

        return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function show($id)
    {
        $shipdistrict = ShipDistrict::findOrFail($id);

        return view('ship-districts.show', compact('shipdistrict'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function edit($id)
    {
        $shipdistrict = ShipDistrict::findOrFail($id);

        return view('ship-districts.edit', compact('shipdistrict'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function update(Request $request, $id)
    {
        
        $requestData = $request->all();
        
        $shipdistrict = ShipDistrict::findOrFail($id);
        $shipdistrict->update($requestData);

        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function destroy($id)
    {
        ShipDistrict::destroy($id);

        return redirect()->back();
    }
}
