<?php

namespace App\Http\Controllers\Ship;

use App\Customer;
use App\District;
use App\Export;
use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\Order;
use App\Order_item;
use App\Ship;
use App\User;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Request;

class ShipsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {

        $ships=Ship::where("type","company")->get();

        return view('ships.index', compact('ships'));
    }

    public function deliveryman_index(Request $request)
    {

        $delivery=Ship::where("type","delivery")->get();

        return view('deliveryman.index', compact('delivery'));
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        return view('ships.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function arraytostr($arr){
        $str="";
        foreach ($arr as $ar){
            $str.=$ar."-";
        }
        return $str;

    }
    public function store(Request $request)
    {

        $requestData = $request->all();
        


        Ship::create($requestData);

        return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function show($id)
    {
        $ship = Ship::findOrFail($id);

        return view('ships.show', compact('ship'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function edit($id)
    {
        $ship = Ship::findOrFail($id);

        return view('ships.edit', compact('ship'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function update(Request $request, $id)
    {

        $requestData = $request->all();
        $ship=Ship::find($id);
/*
        if($request->has("phone")){
            $phones=$ship->get_phones();
            //$phones[$request->index]=$request->value;
            $ship->phone=($request->phone);
            $ship->save();
            return "1";

        }

        else{
            $ship->update($request->all());

        }
*/            $ship->update($request->all());

             return redirect()->back();
}

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function destroy($id)
    {
        Ship::destroy($id);

        return redirect()->back();
    }

    public function orders($id){
        $arr=[];
        $dates=Order::where("ship_id",$id)->orderBy('created_at', 'DESC')->pluck("created_at");
        foreach ($dates as $date){
            $arr[]=explode(" ",$date)[0];

        }
        $arr=array_unique($arr);


        $arr2=[];
        foreach ($arr as $ar){

            $arr2[]=substr($ar,0,7);

        }
        $arr2=array_unique($arr2);

        $final=new Collection([]);

        $final2=[];
        $months=[];
        $items_count=[];

        foreach ($arr2 as $month){
            $final2=[];
            foreach ($arr as $day){
                $temp_count=0;
                if(substr($day,0,7)==$month){
                    $final2[$day]=Order::where("ship_id",$id)->whereDate('created_at',"=", $day)->get(["total_price_after_discount","id"]);
                    foreach ($final2[$day] as $order){

                        $temp_count+=$order->items()->sum("quantity");
                    }
                    $items_count[$day]=$temp_count;

                }
            }
            $months[$month]=$final2;




            /*$final=$final->merge(Order::where('created_at', ">=", $ar)->get());

            $final2[$ar]= Order::whereDate('created_at',"=", $ar)->get();
*/


        }


        /*  for ($i=0;$i<sizeof($final2);$i++){
              $final2[$i]=explode(" ",$final2[$i])[0];

          }
          $final2=array_unique($final2);*/
        /*  foreach($months["2019-11"] as $day=>$items){
              dd($day);
          }
         dd($items);
        dd($months["2019-11"]);*/

        $has_id=0;
        $ships=Ship::all();
        $ship_id=$id;
        $users=User::all();
        $orders=Order::where("ship_id",$id)->orderBy('created_at', 'DESC')->get();
        $districts=District::all();
        $orders_with_the_ship=Order::where("ship_id",$ship_id)->where("state","تم التسليم لشركة الشحن")->orWhere("state","تم الشحن")->orWhere("state","مرتجع")->orWhere("state","مرتجع جزئي")->get();
        $number_of_items_with_the_ship=Order_item::whereIn("order_id",$orders_with_the_ship->pluck("id")->toArray())->count();
        $orders_restoreds_with_the_ship=Order::where("ship_id",$ship_id)->where("state","مرتجع")->count();
        $orders_delivered_with_the_ship=Order::where("ship_id",$ship_id)->where("state","تم الشحن")->get();
        $money_with_the_ship=$orders_delivered_with_the_ship->sum("total_price_after_discount")-$orders_delivered_with_the_ship->sum("delivery");
        $money_paid_with_the_ship=Ship::find($id)->payments()->sum("amount");

        $orders_with_the_ship=$orders_with_the_ship->count();
        $orders_delivered_with_the_ship=$orders_delivered_with_the_ship->count();

        $delivery_man=Ship::where("type","delivery")->get();

        return view('orders.ship_orders',compact("months","districts","final2","arr2","final","has_id","ships","items_count","ship_id","users","delivery_man","orders","orders_with_the_ship","number_of_items_with_the_ship","orders_restoreds_with_the_ship","orders_delivered_with_the_ship","money_with_the_ship","money_paid_with_the_ship"));



    }
}
