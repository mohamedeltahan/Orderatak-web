<?php

namespace App\Http\Controllers\Restored;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\Item;
use App\Restored;
use App\Store;
use Illuminate\Http\Request;

class RestoredsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        $restoreds=null;
        $flag_that_all_items_are_passed="true";
        if($request->has("ship_id")){

            
        if($request->has("store_id")){
            $restoreds=Restored::where("store_id",$request->store_id)->where("ship_id",$request->ship_id)->get();
            $flag_that_all_items_are_passed=$request->store_id;
 
        }
        else{
            $restoreds=Restored::where("ship_id",$request->ship_id)->get();
 
        }
        $stores=Store::all();

        $restored_quantity=$restoreds->sum("quantity");
        //$restored_order_count=sizeof(Restored::all()->pluck("order_id")->unique());
        $confirmed_restored=$restoreds->where("confirmed",1)->count();
        $unconfirmed_restored=$restoreds->where("confirmed",0)->count();



        return view('restoreds.index', compact('restoreds','restored_quantity','unconfirmed_restored','confirmed_restored','flag_that_all_items_are_passed','restoreds','stores'));


        }

        if($request->has("store_id")){
            $restoreds=Restored::where("store_id",$request->store_id)->get();
            $flag_that_all_items_are_passed=$request->store_id;
 
        }
        else{
            $restoreds=Restored::all();
 
        }
        $stores=Store::all();

        $restored_quantity=Restored::all()->sum("quantity");
        //$restored_order_count=sizeof(Restored::all()->pluck("order_id")->unique());
        $confirmed_restored=Restored::where("confirmed",1)->count();
        $unconfirmed_restored=Restored::where("confirmed",0)->count();



        return view('restoreds.index', compact('restoreds','restored_quantity','unconfirmed_restored','confirmed_restored','flag_that_all_items_are_passed','restoreds','stores'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        return view('restoreds.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function store(Request $request)
    {

        $requestData = $request->all();

        Restored::create($requestData);

        return redirect('restoreds')->with('flash_message', 'Restored added!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function show($id)
    {
        $restored = Restored::findOrFail($id);

        return view('restoreds.show', compact('restored'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function edit($id)
    {
        $restored = Restored::findOrFail($id);

        return view('restoreds.edit', compact('restored'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function update(Request $request, $id)
    {

        $requestData = $request->all();

        $restored = Restored::findOrFail($id);
        $restored->update($requestData);

        return redirect('restoreds')->with('flash_message', 'Restored updated!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function destroy($id)
    {
        Restored::destroy($id);

        return redirect('restoreds')->with('flash_message', 'Restored deleted!');
    }
    public function confirm($id){
        $restored=Restored::find($id);
        $item=Item::where("name_id",$restored->name_id)->where("size",$restored->size)->where("store_id",$restored->store_id)->first();
       
        if($item==null){
        $item=Item::where("name_id",$restored->name_id)->where("size",$restored->size)->first();
        }
      
        $item->quantity=$item->quantity+$restored->quantity;
        $restored->confirmed=1;
        $restored->save();

        $item->save();
        return $restored->id;



    }
}
