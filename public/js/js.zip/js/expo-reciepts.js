/*calculate total price of the day*/
import  {validate} from "./form-validation.js";

$(function() {
    $(".month").each(function() {
        var $totalorderprice = 0;
        $(this).find(".orderprice").each(function() {
            $totalorderprice = parseInt($totalorderprice, 10) + parseInt($(this).text(), 10);
        });
        $(this).find(".monthfooter span .num").text($totalorderprice);
    });
});
/*calculate total price of the month*/
$(function() {
    $(".order").each(function() {
        var $totalofmonth = 0;
        $(this).find(".monthfooter span .num").each(function() {
            $totalofmonth = parseInt($totalofmonth, 10) + parseInt($(this).text(), 10);
        });
        $(this).find(".totalmonth span").text("اجمالي الشهر : " + $totalofmonth + $("#currency").val());
    });
});
/*======================== */
$(function() {
    $(".dateheader").click(function() {
        $(".orderdetails").removeClass("hidden_order");

        if(  $(this).parent().hasClass("orderchange")){
            $(".order").removeClass("orderchange");
            return;
        }
        $(".order").removeClass("orderchange");

        $(this).parent().toggleClass("orderchange");
        $(".month").removeClass("changemonth");
        $(".month").removeClass("widthbro");
        $(".month").find(".orderstable").addClass("toggeltable");

    });
    $(".ordersdate").click(function() {
        $(".orderdetails").removeClass("hidden_order");

        $(".month").toggleClass("widthbro");
        $(this).parent().removeClass("widthbro");
        $(this).parent().toggleClass("changemonth");
        $(this).parent().find(".orderstable").toggleClass("toggeltable");
    });
});
$(function() {
    //casher popup close function
    $(".closepopup").click(function() {
        $(this).parent().fadeOut();
        $('.category').removeClass('categoryclick');
        $("#exportpage").addClass('categoryclick');
    });
    // ===========================================================
    //casher popup open function
    $("#casher").click(function() {
        $(".casherpopupcontainer").fadeIn();
        $(this).addClass('categoryclick');
    });
    //open exports popup
    $("#addexports").click(function() {
        $(".add-exports-pop-up-container").fadeIn();
    });
});

$(function(){
    //open add exporter popup when the user cliecked on "add exporter button"
 /*   $(".payed-details").click(function(){
        var $val=$(this).find(".unpaid").text();
        $(".unpaid_val").text($val)
        $("#export_id").val($(this).attr("data-id"));
        $(".add-popup-container").addClass("open-popup");
    });
    //close add exporter popup when the user cliecked on " x button"
    $(".close-popup").click(function(){
        $(this).parent().removeClass("open-popup");
        $(".filled_dynamically").remove();
    });
    $(".close-pop").click(function(){
        $(".add-popup-container").removeClass("open-popup");
    });*/
});
/*=========================================================== */
/*items popup */
$(".itemsinorder").click(function() {
    $(this).parent().find(".TotalItemsInOrderPopupContainer").fadeIn();
});
/*delete export from exports table */
$(".delete").click(function(){
    var temp=$(this);
    $("#alert_modal_button").click();

    $(".confirm_delete").click(function(){

        temp.parent().find(".delete_button").click();
    });

});
$(".delete_item").click(function(){
    var temp=$(this);
    $("#alert_modal_button").click();
    $(".TotalItemsInOrderPopupContainer").css("z-index",1);

    $(".confirm_delete").click(function(){

        temp.find(".delete_button").click();
    });

});
/*transaction popup */
$(".payed-details").click(function() {
    $("#paytransaction").fadeIn();
});
$("#button").click(function () {
    if( validate(["all"],[["null_input"]])){
        $("#submit").click();

    }

});
$(".search_button").click(function () {
    if($("#example_filter #search_option").find("option:selected").val()==="none"){
        alert("اختر وسيلة البحث");
        return;
    }
    var value=$("#example_filter #search").val();
    if(value.length===0){return;}
    var found=false;
    var object={};
    object["id"]=value;
    if($("#example_filter #search_option").find("option:selected").val()==="order_id"){
        object["type"]="order_id";
    }
    else{
        object["type"]="policy_id";

    }

    var url=$("#search_url").val();
    var result=null;

    if($(this).attr("id")==="search_button_with_policy"){
        $(".policy_id").each(function () {
            if($(this).text()===value){
                $(".order").addClass("hidden_order");
                $(this).parent().parent().parent().parent().parent().parent().parent().find(".dateheader").click();
                $(this).parent().parent().parent().parent().parent().find(".ordersdate").click();
                $(this).parent().parent().parent().parent().parent().find(".ordersdate").parent().parent().parent().removeClass("hidden_order");

                $(".orderdetails").addClass("hidden_order");
                $(this).parent().removeClass("hidden_order");
                return false;
            }});}
    else{
        $(".number").each(function () {
            if($(this).text()===value){
                $(".order").addClass("hidden_order");
                $(this).parent().parent().parent().parent().parent().parent().parent().find(".dateheader").click();
                $(this).parent().parent().parent().parent().parent().find(".ordersdate").click();
                $(this).parent().parent().parent().parent().parent().find(".ordersdate").parent().parent().parent().removeClass("hidden_order");

                $(".orderdetails").addClass("hidden_order");
                $(this).parent().removeClass("hidden_order");
                return false;

            }});

    }

    /*if(found===false) {
        if ($.ajax({
            url: url,
            type: "post",
            async: false,
            //request data
            data: object,
            success: function (r) {
                result = r;

            },
            error: function (data) {
                alert('Error on updating, please try again later!');
                return false;
            }
        })) {
            var temp = $("." + result.date).parent();
            var table = $("<table></table>");


            var tr = $("#temp").clone();

            tr.detach();
            tr.attr("id", result.id);

            tr.find(".id").text(result.id);
            tr.find(".username").text(result.username);
            tr.find(".state").parent().attr('data-id', result.id);
            tr.find(".ship").parent().attr('data-id', result.id);

            tr.find(".state option[value='" + result.state + "']").attr('selected', 'selected');
            // tr.find(".state").val("تم التاكيد");
            tr.find(".count").text(result.no_of_items);

            tr.find(".hour").text(result.hour);
            tr.find(".delivery").text(result.delivery);

            tr.find(".receiving_address").text(result.receiving_address);
            tr.find(".customer_name").text(result.customer_name);
            tr.find(".ship option[value='" + result.ship_id + "']").attr('selected', 'selected');
            tr.find(".policy_id").text(result.policy_id);
            tr.find(".link").text(result.id);
            tr.find(".link").attr("href", result.link);
            tr.find(".destroy_form").attr("action", result.destroy_link);
            tr.find(".total_price_after_discount").text(result.total_price_after_discount);
            table.append(tr);


            //     temp.parent().find("table").append("<tr><td>"+result[i].id+"</td><td>"+result[i].username+"</td><td>dsadasd</td><td>"+result[i].no_of_items+"</td><td>"+result[i].hour+"</td><td>"+result[i].delivery+"</td><td>"+result[i].customer_name+"</td><td>dsadasd</td></tr>");
        }

        temp.parent().find("table").append(table.html());
        $(".policy_id").each(function () {
            if($(this).text()==value){
                $(this).parent().parent().parent().parent().parent().parent().parent().find(".dateheader").click();
                $(this).parent().parent().parent().parent().parent().find(".ordersdate").click();
                $(".orderdetails").addClass("hidden_order");
                $(this).parent().removeClass("hidden_order");
                return false;
            }});


    }

           /*$(".number").each(function () {
               if($(this).find("a").text()===val){
                   $(this).parent().parent().parent().parent().parent().parent().parent().find(".dateheader").click();
                   $(this).parent().parent().parent().parent().parent().find(".ordersdate").click();
                   $(".orderdetails").addClass("hidden_order");
                   $(this).parent().removeClass("hidden_order");
                   /*    $(".month").toggleClass("widthbro");
                       $(this).parent().removeClass("widthbro");
                       $(this).parent().toggleClass("changemonth");
                       $(this).parent().find(".orderstable").toggleClass("toggeltable");*/
    /*   $(".month").removeClass("changemonth");
       $(".month").removeClass("widthbro");
       $(".order").removeClass("orderchange");

       var obj=$(this).parent().parent().parent().parent().parent();
       //  $(obj).parent().find(".dateheader").toggleClass("orderchange");

       $(obj).parent().parent().toggleClass("orderchange");
       $(".month").find(".orderstable").addClass("toggeltable");

       $(".month").toggleClass("widthbro");
       $(obj).removeClass("widthbro");
       $(obj).toggleClass("changemonth");
       $(obj).find(".orderstable").toggleClass("toggeltable");


   }
})*/
});
function e2a_numbers(input,$id) {
    for(var i=0;i<input.length;i++){
        switch (input[i]) {
            case "٠":
                input = input.replace("٠",0);

                break;
            case "١":
                input = input.replace("١",1);

                break;
            case "٢":
                input = input.replace("٢",2);

                break;
            case "٣":
                input = input.replace("٣",3);

                break;
            case "٤":
                input = input.replace("٤",4);

                break;
            case "٥":
                input = input.replace("٥",5);
                break;
            case "٦":
                input = input.replace("٦",6);

                break;
            case "٧":
                input = input.replace("٧",7);

                break;
            case "٨":
                input = input.replace("٨",8);
                break;
            case "٩":

                input = input.replace("٩",9);
                break



        }
    }
    $("#"+$id).val(input);
}

$(".paste").keyup(function(){

    e2a_numbers($(this).val(),$(this).attr("id"));
});
/*
$(document).mouseup(function (e) {
   var temp= $(".exportscontainer");
    if (temp.is(e.target)){
        $(".order").removeClass("orderchange");
    }
});
*/
